package com.brainmentors.springmvcjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcjdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmvcjdbcApplication.class, args);
	}

}
