package com.brainmentors.springmvcjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcjdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
