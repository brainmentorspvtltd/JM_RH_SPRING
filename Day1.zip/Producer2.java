public class Producer2 {

}
