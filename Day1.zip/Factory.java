public class Factory {
    public static IProducer createObject() {
        IProducer producer = new ImproveProducer();
        return producer;
    }
}
