package com.brainmentors.firstapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

// @Configuration - Bean Config This class is a Spring configuration class
// @EnableAutoConfiguration - Spring Boot automatically configures beans based on dependencies in classpath.
// @ComponentScan
@SpringBootApplication
// POJO
/*
 * @SpringBootApplication =@Configuration + @EnableAutoConfiguration
 * + @ComponentScan
 * 
 */
public class FirstappApplication {

	public static void main(String[] args) {
		/*
		 * This starts your Spring Boot application.
		 * It boots the Spring container, configures everything, and starts the web
		 * server.
		 * 
		 * 👉 This line turns your normal Java program into a running backend server.
		 * When you run this line, Spring Boot does ALL of this automatically:
		 */
		// ApplicationContext
		/*
		 * Create Spring Application Context
		 * 
		 * 👉 Spring creates a container (ApplicationContext).
		 * 
		 * This container:
		 * • Manages objects (Beans)
		 * • Handles dependency injection
		 * • Controls lifecycle
		 * 
		 * 📌 This is IoC Container.
		 */
		SpringApplication.run(FirstappApplication.class, args);
	}

}
