package com.brainmentors.firstapp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.brainmentors.firstapp.models.User;

@RestController
public class UserController {
    // String Response
    @GetMapping("/")
    public String sayHello() {
        return "Welcome to Spring Boot";
    }

    // JSON Response
    @GetMapping("/get-user")
    public User getUser() {
        User user = new User();
        user.setEmailId("amit@brain-mentors.com");
        user.setName("⭐️⭐️Amit");
        user.setPhone("222222");
        return user;
    }

    // JSON Response with List of Data
    @GetMapping("/get-users")
    public List<User> getUsers() {
        List<User> users = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            users.add(new User("amit" + i + "@mail.com",
                    "Amit" + i, "999" + i));
        }
        return users;
    }

    // Query String Parameter e.g ?q=Mobile&limit=20
    @GetMapping("/search")
    public String getUserInfo(@RequestParam(defaultValue = "shoes") String q,
            @RequestParam(defaultValue = "10") String limit) {
        return "Hello " + q + " " + limit;
    }

    @GetMapping("/searching")
    public String getPagination(@RequestParam() String start, @RequestParam() String limit) {
        return "Pagination " + start + " " + limit;
    }

    @GetMapping("/path-params/{brandName}/{price}")
    public String getPathParam(@PathVariable String brandName, @PathVariable double price) {
        return "Path Params are " + brandName + " " + price;
    }

    @GetMapping("/get-user-response")
    public ResponseEntity<User> getUserResponse() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("BrainMentors-App-Version", "1.0");
        User user = new User("abcd@mail.com", "abcd", "1111");
        return ResponseEntity.status(HttpStatus.OK)
                .headers(headers).header("Authorization", "jwt-token-123").body(user);
    }

}
