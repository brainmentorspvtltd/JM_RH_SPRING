package com.brainmentors.firstapp.models;

public class User {
    private String emailId;

    private String name;
    private String phone;

    public User() {

    }

    public User(String emailId, String name, String phone) {
        this.emailId = emailId;
        this.name = name;
        this.phone = phone;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
