package com.brainmentors.firstapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstappApplicationTests {

	@Test
	void contextLoads() {
	}

}
