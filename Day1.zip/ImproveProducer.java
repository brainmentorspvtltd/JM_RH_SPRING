public class ImproveProducer implements IProducer {
    @Override
    public void show() {
        System.out.println("I am the Fast Show....");
    }
}
