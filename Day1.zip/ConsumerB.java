public class ConsumerB {
    public static void main(String[] args) {
        IProducer producer = Factory.createObject();
        producer.show();
    }
}
