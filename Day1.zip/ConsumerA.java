public class ConsumerA {
    public static void main(String[] args) {
        int x = (int) 90.20;
        // IProducer producer = new Producer();
        IProducer producer = Factory.createObject();
        producer.show();
        // producer.dontShow();
    }
}
