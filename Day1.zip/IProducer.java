public abstract interface IProducer {
    public abstract void show();
}
// 100 % Abstract
// What to do
