class Producer implements IProducer {
    @Override
    public void show() {
        System.out.println("I am the Producer Show");
        dontShow();
    }

    public void dontShow() {
        System.out.println("Dont Show to the Consumer");
    }
}