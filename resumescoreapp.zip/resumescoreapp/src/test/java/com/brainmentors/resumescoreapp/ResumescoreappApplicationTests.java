package com.brainmentors.resumescoreapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumescoreappApplicationTests {

	@Test
	void contextLoads() {
	}

}
