package com.brainmentors.resumescoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumescoreappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumescoreappApplication.class, args);
	}

}
